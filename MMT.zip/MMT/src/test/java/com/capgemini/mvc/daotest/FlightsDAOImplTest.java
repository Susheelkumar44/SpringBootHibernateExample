package com.capgemini.mvc.daotest;

import static org.junit.Assert.*;
import java.util.ArrayList;
import java.util.List;

import static org.mockito.Mockito.*;
import org.junit.Test;

import com.capgemini.mvc.model.FlightsPojo;
import com.capgemini.mvc.service.FlightService;

public class FlightsDAOImplTest {

	@Test
	public void test() {
		fail("Not yet implemented");
		ArrayList<FlightsPojo> flights=new ArrayList<FlightsPojo>();
		FlightsPojo googleFlightsPojo = new FlightsPojo("BLR", "DEL", "20181010","AirAsia",2879,"4:30","1:30");
		FlightsPojo microsoftFlightsPojo = new FlightsPojo("BLR", "BOM", "20181010","AirAsia",2879,"4:30","1:30");

		flights.add(googleFlightsPojo);
		flights.add(microsoftFlightsPojo);

		// Create the mock object of FlightsPojo service
		FlightService FlightsPojoServiceMock = mock(FlightService.class);

		// mock the behavior of FlightsPojo service to return the value of various FlightsPojos
		/*when(FlightsPojoServiceMock.getPrice(googleFlightsPojo)).thenReturn(50.00);
		when(FlightsPojoServiceMock.getPrice(microsoftFlightsPojo)).thenReturn(1000.00);
*/
	}

}
