package com.capgemini.mvc.dao;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.capgemini.mvc.controller.FlightController;
import com.capgemini.mvc.model.FlightsPojo;
import com.capgemini.mvc.service.FlightService;

public class FlightsDAOImpl {
	public ArrayList<FlightsPojo> search(String src, String dest) {
		Logger logger = LoggerFactory.getLogger(FlightController.class);
		ArrayList<FlightsPojo> listFlights = new ArrayList<FlightsPojo>();
		try {
			File fXmlFile = new File("C:\\Users\\sushes\\Downloads\\MMT\\test3.xml");
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(fXmlFile);
			// optional, but recommended
			// read this -
			// http://stackoverflow.com/questions/13786607/normalization-in-dom-parsing-with-java-how-does-it-work
			doc.getDocumentElement().normalize();
			logger.info("Root element :" + doc.getDocumentElement().getNodeName());
			NodeList nList = doc.getElementsByTagName("data");
			logger.info("----------------------------");
			// for (int temp = 0; temp < nList.getLength(); temp++) {
			Node nNode = nList.item(0);
			Element eElement = (Element) nNode;
			int temp = eElement.getElementsByTagName("origin").getLength();
			String length = Integer.toString(temp);
			logger.info(length);

			// FlightsPojo flights=new FlightsPojo()
			logger.info("\nCurrent Element :" + nNode.getNodeName());
			for (int i = 0; i < temp; i++) {
				if (nNode.getNodeType() == Node.ELEMENT_NODE) {

					// System.out.println("Origin : " + eElement.getAttribute("id"));

					String origin = eElement.getElementsByTagName("origin").item(i).getTextContent();
					String destination = eElement.getElementsByTagName("destination").item(i).getTextContent();
					String date = eElement.getElementsByTagName("depdate").item(i).getTextContent();
					String arrival = eElement.getElementsByTagName("arrtime").item(i).getTextContent();
					String departure = eElement.getElementsByTagName("deptime").item(i).getTextContent();
					String airline = eElement.getElementsByTagName("airline").item(i).getTextContent();
					String fare = eElement.getElementsByTagName("adulttotalfare").item(i).getTextContent();
					int fareInt = Integer.parseInt(fare);
					if (src.equals(origin) && dest.equals(destination)) {
						FlightsPojo flight = new FlightsPojo(origin, destination, date, airline, fareInt,arrival,departure);
						listFlights.add(flight);
					}
					/*
					 * logger.info("Origin : " +
					 * eElement.getElementsByTagName("origin").item(i).getTextContent());
					 * logger.info("Destination : " +
					 * eElement.getElementsByTagName("destination").item(i).getTextContent());
					 * logger.info("Date : " +
					 * eElement.getElementsByTagName("depdate").item(i).getTextContent());
					 * logger.info("Arrival : " +
					 * eElement.getElementsByTagName("arrtime").item(i).getTextContent());
					 * logger.info("Departure : " +
					 * eElement.getElementsByTagName("deptime").item(i).getTextContent());
					 * logger.info("Airline : " +
					 * eElement.getElementsByTagName("airline").item(i).getTextContent());
					 * logger.info("Fare : " +
					 * eElement.getElementsByTagName("adulttotalfare").item(i).getTextContent());
					 * //logger.info(i); logger.info("***********************************");
					 */
				}

			}
			// }

		} catch (Exception e) {
			e.printStackTrace();
		}
		/*System.out.println(listFlights);*/
		Collections.sort(listFlights, FlightService.FareComparator);
		/*for (FlightsPojo str : listFlights) {
			System.out.println(str);
		}*/

		// Collections.sort(listFlights, FlightsPojo.getFare());
		// List flightDetails =
		// Arrays.asList(listFlights).stream().sorted().collect(Collectors.toList());
		// System.out.println(flightDetails);
		// model.addAttribute("listFlights", listFlights);
		return listFlights;
	}
}
