package com.capgemini.mvc.service;

import java.util.Comparator;

import org.springframework.stereotype.Service;

import com.capgemini.mvc.model.FlightsPojo;

@Service
public class FlightService {
	public static Comparator<FlightsPojo> getFareComparator() {
		return FareComparator;
	}
	public static void setFareComparator(Comparator<FlightsPojo> fareComparator) {
		FareComparator = fareComparator;
	}
	public static Comparator<FlightsPojo> FareComparator = new Comparator<FlightsPojo>() {

		public int compare(FlightsPojo flight1, FlightsPojo flight2) {
			int Flight1 = flight1.getFare();
			int Flight2 = flight2.getFare();

			// ascending order
			return Flight1 - Flight2;

			// descending order
			// return StudentName2.compareTo(StudentName1);
		}
	};
}
