package com.capgemini.mvc.dao;

import java.util.ArrayList;

import com.capgemini.mvc.model.FlightsPojo;

public interface FlightsDAO {
	public ArrayList<FlightsPojo> search(String src, String dest);
}
