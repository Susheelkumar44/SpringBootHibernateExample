package com.capgemini.mvc.model;

import java.util.Comparator;

public class FlightsPojo {
	String source;
	String destination;
	public FlightsPojo(String source, String destination, String date, String airline, int fare,
			String arrival, String departure) {
		super();
		this.source = source;
		this.destination = destination;
		this.date = date;
		this.arrival = arrival;
		this.departure = departure;
		this.fare = fare;
		this.airline = airline;
	}
	String date,arrival,departure;
	public String getDeparture() {
		return departure;
	}
	public void setDeparture(String departure) {
		this.departure = departure;
	}
	int fare;
	
	public int getFare() {
		return fare;
	}
	public void setFare(int fare) {
		this.fare = fare;
	}
	public String getAirline() {
		return airline;
	}
	public void setAirline(String airline) {
		this.airline = airline;
	}
	String airline;
	
	
	@Override
	public String toString() {
		return "FlightsPojo [source=" + source + ", destination=" + destination + ", date=" + date + ", arrival="
				+ arrival + ", departure=" + departure + ", fare=" + fare + ", airline=" + airline + "]";
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getDestination() {
		return destination;
	}
	public String getArrival() {
		return arrival;
	}
	public void setArrival(String arrival) {
		this.arrival = arrival;
	}
	
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	
	public FlightsPojo() {
		super();
		// TODO Auto-generated constructor stub
	}

	
}
