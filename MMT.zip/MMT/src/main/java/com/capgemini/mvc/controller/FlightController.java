package com.capgemini.mvc.controller;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpSession;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import com.capgemini.mvc.model.FlightsPojo;
import com.capgemini.mvc.service.FlightService;

import com.capgemini.mvc.dao.FlightsDAOImpl;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.XML;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.springframework.web.servlet.ModelAndView;
import javax.servlet.http.HttpServletRequest;

@RestController
public class FlightController {
	Logger logger = LoggerFactory.getLogger(FlightController.class);
	static Model model;

	@RequestMapping(value = "/flightSearch", method = RequestMethod.GET)

	public ModelAndView valid(Model model, @ModelAttribute("source") String source,
			@ModelAttribute("destination") String destination, @ModelAttribute("date") String departDate)
			throws IOException, JSONException {
		FlightsDAOImpl ob=new FlightsDAOImpl();
		String src = source;
		String dest = destination;
		String depDate = departDate;
		src = source.substring(1, 4);
		logger.info(src);
		dest = destination.substring(1, 4);
		logger.info(dest);
		logger.info(depDate);
		String url = "https://developer.goibibo.com/api/search/?app_id=8a66fa9d&app_key=354e60db1b1ef0967f1ea0a5d1626b00&format=json&source="
				+ src + "&destination=" + dest + "&dateofdeparture=" + depDate
				+ "&seatingclass=E&adults=1&children=0&infants=0&counter=100";
		JSONObject json = readJsonFromUrl(url);// System.out.println(json.toString());
		String xml = XML.toString(json);
		// System.out.println(xml);
		// System.out.println(json.get("id"));
		try {
			File file = new File("test3.xml");
			FileWriter fileWriter = new FileWriter(file);
			fileWriter.write("<response>");
			fileWriter.write(xml);
			fileWriter.write("</response>");
			fileWriter.flush();
			fileWriter.close();
			
			ArrayList<FlightsPojo> listFlight = ob.search(src, dest);
			model.addAttribute("listFlights", listFlight);
		} catch (IOException e) {
			e.printStackTrace();
		}
		// model.addAttribute("listFlights", listFlight);
		return new ModelAndView("flightSearch");
	}

	private static String readAll(Reader rd) throws IOException {
		StringBuilder sb = new StringBuilder();
		int cp;
		while ((cp = rd.read()) != -1) {
			sb.append((char) cp);
		}
		return sb.toString();
	}

	public static JSONObject readJsonFromUrl(String url) throws IOException, JSONException {
		InputStream is = new URL(url).openStream();
		try {
			BufferedReader rd = new BufferedReader(new InputStreamReader(is, Charset.forName("UTF-8")));
			String jsonText = readAll(rd);
			JSONObject json = new JSONObject(jsonText);
			return json;
		} finally {
			is.close();
		}
	}

	

}
