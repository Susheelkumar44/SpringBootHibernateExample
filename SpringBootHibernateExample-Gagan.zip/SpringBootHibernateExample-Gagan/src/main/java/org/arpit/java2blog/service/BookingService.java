package org.arpit.java2blog.service;
import java.util.List;

import javax.sql.DataSource;

import org.arpit.java2blog.dao.BookingDao;

import org.arpit.java2blog.model.Flights;
import org.hibernate.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

@Service("bookingService")
public class BookingService{
	
	@Autowired
	BookingDao bookingDao;
	
       @Autowired
       DataSource dataSource;
       
       @Autowired
       JdbcTemplate jdbcTemplate;

       public List<Flights> getFlight(int flightid) {
              return bookingDao.getFlight(flightid);
       }
}

