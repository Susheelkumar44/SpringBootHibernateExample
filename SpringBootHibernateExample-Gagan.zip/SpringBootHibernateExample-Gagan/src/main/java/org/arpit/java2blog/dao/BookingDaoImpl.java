package org.arpit.java2blog.dao;

import java.util.List;

import org.arpit.java2blog.model.Flights;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public class BookingDaoImpl implements BookingDao {
	@Autowired
    private SessionFactory sessionFactory;

    public void setSessionFactory(SessionFactory sf) {
           this.sessionFactory = sf;
    }
    
    @Transactional
    public List<Flights> getFlight(int flightid) {
    		int id=flightid;
           Session session = this.sessionFactory.getCurrentSession();
           
		   List<Flights>  flightList = session.createQuery("from Flights where flightid = '"+id+"'").list();
		   
           System.out.println(flightList);
           System.out.println(id);
           return flightList;
    }
    
}
