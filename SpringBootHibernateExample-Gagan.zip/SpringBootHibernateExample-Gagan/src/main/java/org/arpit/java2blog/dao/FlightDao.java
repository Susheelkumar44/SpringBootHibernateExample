package org.arpit.java2blog.dao;

import java.util.List;

import org.arpit.java2blog.model.Flights;


public interface FlightDao {
	 public List<Flights> getAllFlights() ;

}
