package org.arpit.java2blog.controller;
import org.arpit.java2blog.model.Flights;
import org.arpit.java2blog.service.BookingService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class ConfirmController {
	@RequestMapping(value = "/confirm/{passengerCount}", method = RequestMethod.GET, headers = "Accept=application/json")
			public String getAllCustomers(Model model,@PathVariable String passengerCount) {
		int passengerCount1=Integer.parseInt(passengerCount);
		int price=150*passengerCount1;
		System.out.println("111");
		/*if(travelClass=="Premium Economy")
		{
			price=(int) (price*1.5);
		}
		else {
			price=price*2;
		}*/
        return "confirm";
 }

}
